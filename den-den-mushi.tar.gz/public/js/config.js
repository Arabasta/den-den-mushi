export const config = {
    port: 45005,
    maxReconnectAttempts: 3,
    reconnectDelay: 2000
};